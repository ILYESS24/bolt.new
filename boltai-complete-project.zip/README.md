# BoltAI - AI-Powered Code Generator

A modern web application for AI-powered code generation and project creation, inspired by bolt.new but built from scratch with original code and design.

## Features

- 🤖 **AI-Powered Code Generation**: Generate code instantly with OpenAI GPT-4 integration
- 🚀 **Quick Project Creation**: Create new projects with a single prompt from the homepage
- 💻 **Integrated Code Editor**: Monaco Editor with syntax highlighting and IntelliSense
- 📁 **File Management**: Create, edit, and organize multiple files in your projects
- 🖥️ **Integrated Terminal**: Run commands and see output directly in the browser
- 🔐 **Authentication**: Secure authentication with email/password and OAuth (Google, GitHub)
- 📊 **Dashboard**: Organize and manage all your projects in one place
- 🔗 **Unique URLs**: Each project gets its own unique URL for easy sharing
- 🌐 **Public/Private**: Control visibility of your projects
- 📱 **Responsive Design**: Works perfectly on desktop and mobile devices
- ⚡ **Fast & Modern**: Built with Next.js 14, TypeScript, and TailwindCSS
- 🎨 **Modern UI**: Beautiful, bolt.new-inspired interface with animations

## Tech Stack

- **Frontend**: Next.js 14, React 18, TypeScript
- **Styling**: TailwindCSS with custom design system
- **Code Editor**: Monaco Editor (VS Code editor)
- **AI Integration**: OpenAI GPT-4 API
- **State Management**: Zustand
- **Authentication**: NextAuth.js with multiple providers
- **Database**: SQLite with Prisma ORM
- **Icons**: Lucide React
- **Animations**: Framer Motion
- **Notifications**: React Hot Toast
- **Deployment**: Vercel-ready

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn
- Git

### Installation

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd project-builder
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env.local
   ```
   
   Edit `.env.local` and add your configuration:
   ```env
   # Database
   DATABASE_URL="file:./dev.db"
   
   # NextAuth
   NEXTAUTH_URL="http://localhost:3000"
   NEXTAUTH_SECRET="your-secret-key-change-in-production"
   
   # OAuth (optional)
   GOOGLE_CLIENT_ID="your-google-client-id"
   GOOGLE_CLIENT_SECRET="your-google-client-secret"
   GITHUB_CLIENT_ID="your-github-client-id"
   GITHUB_CLIENT_SECRET="your-github-client-secret"
   
   # OpenAI (required for AI features)
   OPENAI_API_KEY="your-openai-api-key"
   ```

4. **Set up the database**
   ```bash
   npx prisma generate
   npx prisma db push
   ```

5. **Start the development server**
   ```bash
   npm run dev
   ```

6. **Open your browser**
   Navigate to [http://localhost:3000](http://localhost:3000)

## Project Structure

```
project-builder/
├── components/           # Reusable React components
│   ├── Header.tsx       # Navigation header
│   ├── Footer.tsx       # Site footer
│   ├── Layout.tsx       # Main layout wrapper
│   ├── ProjectCard.tsx  # Project display card
│   └── QuickAction.tsx  # Homepage quick action
├── lib/                 # Utility libraries
│   └── db.ts           # Database connection
├── pages/              # Next.js pages
│   ├── api/            # API routes
│   │   ├── auth/       # Authentication endpoints
│   │   └── projects/   # Project CRUD endpoints
│   ├── auth/           # Authentication pages
│   ├── projects/       # Project pages
│   ├── dashboard.tsx   # User dashboard
│   └── index.tsx       # Homepage
├── prisma/             # Database schema
│   └── schema.prisma   # Prisma schema definition
├── public/             # Static assets
├── styles/             # Global styles
├── types/              # TypeScript type definitions
├── next.config.js      # Next.js configuration
├── tailwind.config.js  # TailwindCSS configuration
└── package.json        # Dependencies and scripts
```

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/signin` - Sign in user
- `GET /api/auth/signout` - Sign out user

### Projects
- `GET /api/projects` - Get user's projects
- `POST /api/projects` - Create new project
- `GET /api/projects/[id]` - Get specific project
- `PUT /api/projects/[id]` - Update project
- `DELETE /api/projects/[id]` - Delete project

## Deployment

### Quick Deploy (Recommended)

#### Vercel (1-Click Deploy)

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/your-username/boltai)

1. **Connect GitHub Repository**
   ```bash
   git add .
   git commit -m "Initial commit"
   git push origin main
   ```

2. **Deploy on Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Import your GitHub repository
   - Add environment variables in Vercel dashboard
   - Deploy!

3. **Set up production database**
   - Add Vercel Postgres database
   - Update `DATABASE_URL` in Vercel environment variables
   - Run `npx prisma db push` after deployment

#### Railway

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/template/your-template)

```bash
npm install -g @railway/cli
railway login
railway init
railway up
```

#### Render

1. Connect your GitHub repository to [Render](https://render.com)
2. Set build command: `npm install && npx prisma generate && npm run build`
3. Set start command: `npm start`
4. Add environment variables
5. Deploy!

### Manual Deployment

```bash
# Check environment
npm run check-env

# Build for production
npm run build:prod

# Deploy to specific platform
npm run deploy:vercel
npm run deploy:railway
```

### Docker Deployment

```bash
# Build Docker image
docker build -t boltai .

# Run container
docker run -p 3000:3000 \
  -e NEXTAUTH_URL=https://your-domain.com \
  -e NEXTAUTH_SECRET=your-secret \
  -e DATABASE_URL=your-database-url \
  -e OPENAI_API_KEY=your-openai-key \
  boltai
```

### Environment Variables for Production

```env
DATABASE_URL="your-production-database-url"
NEXTAUTH_URL="https://your-domain.vercel.app"
NEXTAUTH_SECRET="your-secure-secret-key"
GOOGLE_CLIENT_ID="your-google-client-id"
GOOGLE_CLIENT_SECRET="your-google-client-secret"
GITHUB_CLIENT_ID="your-github-client-id"
GITHUB_CLIENT_SECRET="your-github-client-secret"
```

### OAuth Setup

#### Google OAuth
1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create a new project or select existing
3. Enable Google+ API
4. Create OAuth 2.0 credentials
5. Add authorized redirect URIs:
   - `http://localhost:3000/api/auth/callback/google` (development)
   - `https://your-domain.vercel.app/api/auth/callback/google` (production)

#### GitHub OAuth
1. Go to [GitHub Developer Settings](https://github.com/settings/developers)
2. Create a new OAuth App
3. Set Authorization callback URL:
   - `http://localhost:3000/api/auth/callback/github` (development)
   - `https://your-domain.vercel.app/api/auth/callback/github` (production)

## Development

### Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run lint` - Run ESLint
- `npm run type-check` - Run TypeScript type checking

### Database Management

- `npx prisma studio` - Open Prisma Studio (database GUI)
- `npx prisma db push` - Push schema changes to database
- `npx prisma generate` - Generate Prisma client
- `npx prisma migrate dev` - Create and apply migrations

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

If you encounter any issues or have questions:

1. Check the [Issues](https://github.com/your-username/project-builder/issues) page
2. Create a new issue with detailed information
3. For urgent matters, contact [your-email@example.com]

## Acknowledgments

- Inspired by bolt.new's functionality and user experience
- Built with modern web technologies and best practices
- Designed for simplicity and ease of use

---

**Happy Building! 🚀**